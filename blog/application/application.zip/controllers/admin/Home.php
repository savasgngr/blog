<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->helper('url');
        $this->load->Model('Database_Model');
        $this->load->library('session');
        $this->load->database();
        if(!$this->session->userdata('oturum'))
        {
            $this->session->flashdata("giris_hata","lütfen giriş yapınız");
            redirect(base_url()."admin/Giris");
        }
	}
	public function index()
	{
		$this->load->view('admin/Header');
		$this->load->view('admin/Container');
		$this->load->view('admin/Footer');
		$this->load->view('admin/Sidebar');
	}
	public function giris_yap()
    {
        $this->load->view('admin/Giris');
    }

}
