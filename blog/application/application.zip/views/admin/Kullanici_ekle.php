<?php
$this->load->view('admin/header');
?>
											<div class="outter-wp">
								
											
												<!--/candile-->
													<div class="candile"> 
															<div class="candile-inner">
																	<h3 class="sub-tittle">Yeni Kullanıcı Ekle </h3>
															    <div id="center"><div id="fig">
																<!--Container ara-->
																<div id="page-wrapper" >
																	<div id="page-inner"> 
														<div class="row">
															<div class="col-lg-12">
																<div class="box">
																
																	<div id="collapseOne" class="body">
																		<form action="<?=base_url()?>admin/Kullanicilar/eklekaydet" method="POST" class="form-horizontal ">

																			<div class="form-group">
																				<label class="control-label col-lg-4">Adı soyadı</label>
																				<div class="col-lg-4">
																					<input type="text"  name="adsoy" class="form-control">
																				</div>
																			</div>
																			<div class="form-group">
																				<label class="control-label col-lg-4">Şifre</label>

																				<div class="col-lg-4">
																					<input type="password"  name="sifre" class="form-control">
																				</div>
																			</div>
																			<div class="form-group">
																				<label class="control-label col-lg-4">e-mail</label>

																				<div class="col-lg-4">
																					<input type="email"  name="email" class="form-control">
																				</div>
																			</div>
																		
																			
																			<div class="form-group">
																				<label class="control-label col-lg-4">kayıt tarihi</label>

																				<div class="col-lg-4">
																					<input type="date"  name="kayıt_tarih" class="form-control">
																				</div>
																			</div>
																			<div class="form-group">
																				<label class="control-label col-lg-4">bitiş tarihi</label>

																				<div class="col-lg-4">
																					<input type="date"  name="bitis_tarih" class="form-control">
																				</div>
																			</div>
																			<div class="form-group">
																			<br>
																				<label class="control-label col-lg-4">durum</label>
																				<div class="controle">
																					<select id="selectError" name="durum" data-rel="chosen">
																					<option> onaylı </option>
																					<option>  beklemede</option>
																					<option>  engelli</option>
																					
																					</select>
																				</div>


																			</div>
																		
																		  <div class="form-group">
																				
																				<label class="control-label col-lg-4">Yetki</label>
																				<br>
																				<div class="controle">
																					<select id="selectError" name="yetki" data-rel="chosen">
																					<option>  Admin</option>
																					<option>  editör</option>
																					<option>  kullanıcı</option>
																					<option>  üye</option>
																					</select>
																				</div>
																			</div>
																		   
																		   <button type="submit"  class="btn btn-info icon-blue ">Kaydet</button>
																		 
																		</form>
																	</div>
																</div>
															</div>
															<!-- /.col-lg-12 -->
														</div>	
																					   
														</div>
														</div>     
														
																		 <!-- /. ROW  -->           
														</div>
																	 <!-- /. PAGE INNER  -->
														</div>

																	<!--Container ara Bitiş-->
																				</div>
																			</div>      
																				
																		</div>

															
<?php
$this->load->view('admin/footer');
$this->load->view('admin/sidebar');

?>