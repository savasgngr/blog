 <?php
$this->load->view('admin/header');
?>
<div class="outter-wp">
		<div class="candile">
				<div class="candile-inner">
						<h3 class="tittle">Bu divin içine koy ne koyacaksan </h3>
					
						sbsfbfsdnbsfn
					
				</div>
		</div>
</div>
<?php
$this->load->view('admin/Footer');
$this->load->view('admin/Sidebar');
?>