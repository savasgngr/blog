</div>
							</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo">
					<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="index.html"> <span id="logo"> <h1>Eşsiz Blog</h1></span> 
					<!--<img id="logo" src="" alt="Logo"/>--> 
				  </a> 
				</header>
			<div style="border-top:1px solid rgba(69, 74, 84, 0.7)"></div>
			<!--/down-->
							<div class="down">	
									  <a href="index.html"><img src="<?=base_url()?>assets/admin/images/admin1.jpg"></a>
									  <a href="index.html"><span class=" name-caret">Hasan Akgül</span></a>
									 <p>Sistem Yöneticisi</p>
									</div>
							   <!--//down-->
                           <div class="menu">
									<ul id="menu" >
										<li><a href="<?=base_url()?>admin/Home"><i class="fa fa-tachometer"></i> <span>Panel</span></a></li>
										 <li id="menu-academico" ><a href="<?=base_url()?>admin/Kullanicilar"><i class="fa fa-users"></i> <span> Kullanıcılar</span></a>
										</li>
										 <li id="menu-academico" ><a href="<?=base_url()?>admin/Kategoriler"><i class="fa fa-file-text-o"></i> <span>Kategoriler</span> <span class="fa fa-angle-right" style="float: right"></span></a>
											 <ul id="menu-academico-sub" >
												<li id="menu-academico-avaliacoes" ><a href="forms.html">Yazılar</a></li>
												<li id="menu-academico-boletim" ><a href="validation.html">Onay Bekleyenler</a></li>
											  </ul>
										 </li>
									
									
									 <li><a href="#"><i class="lnr lnr-envelope"></i> <span>Mesajlar</span><span class="fa fa-angle-right" style="float: right"></span></a>
									   <ul>
										<li><a href="inbox.html"><i class="fa fa-inbox"></i> İletişim Mesajları</a></li>
										<li><a href="compose.html"><i class="fa fa-pencil-square-o"></i> Kullanıcı Mesajları</a></li>
										<li><a href="editor.html"><span class="lnr lnr-highlight"></span> Cevaplanmış Mesajlar</a></li>
									
									  </ul>
									</li>
							        <li id="menu-academico" ><a href="<?=base_url()?>admin/Uyeler"><i class="fa fa-user"></i> <span>Üyeler</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										 <ul id="menu-academico-sub" >
											<li id="menu-academico-avaliacoes" ><a href="grids.html">Onaylı Üyeler</a></li>
											<li id="menu-academico-boletim" ><a href="media.html">Onay Bekleyenler</a></li>

										  </ul>
									 </li>
									 
									<li><a href="chart.html"><i class="fa fa-caret-square-o-right"></i> <span>Medya</span> <span class="fa fa-angle-right" style="float: right"></span></a>
									  <ul>
										<li><a href="map.html"><i class="lnr lnr-map"></i> Resim</a></li>
										<li><a href="graph.html"><i class="lnr lnr-apartment"></i> Video</a></li>
									</ul>
									</li>
									<li id="menu-academico" ><a href="#"><i class="lnr lnr-book"></i> <span>Sayfalar</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										  <ul id="menu-academico-sub" >
										    <li id="menu-academico-avaliacoes" ><a href="<?=base_url()?>admin/Giris">Giriş</a></li>
										    <li id="menu-academico-boletim" ><a href="register.html">Register</a></li>
											<li id="menu-academico-boletim" ><a href="<?=base_url()?>admin/Bos">Boş Sayfa</a></li>
											<li id="menu-academico-boletim" ><a href="sign.html">Sign up</a></li>
											<li id="menu-academico-boletim" ><a href="profile.html">Profile</a></li>
										  </ul>
									 </li>
									<li id="menu-comunicacao" ><a href="#"><i class="fa fa-smile-o"></i> <span>More</span><span class="fa fa-angle-double-right" style="float: right"></span></a>
									  <ul id="menu-comunicacao-sub" >
										<li id="menu-mensagens" style="width:120px" ><a href="project.html">Projects <i class="fa fa-angle-right" style="float: right; margin-right: -8px; margin-top: 2px;"></i></a>
										  <ul id="menu-mensagens-sub" >
											<li id="menu-mensagens-enviadas" style="width:130px" ><a href="ribbon.html">Ribbons</a></li>
											<li id="menu-mensagens-recebidas"  style="width:130px"><a href="blank.html">Blank</a></li>
										  </ul>
										</li>
										<li id="menu-arquivos" ><a href="500.html">500</a></li>
									  </ul>
									</li>
									<li><a href="<?=base_url()?>admin/Ayarlar"><i class="lnr lnr-pencil"></i> <span>Ayarlar</span></a></li>
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<link rel="stylesheet" href="<?=base_url()?>assets/admin/css/vroom.css">
<script type="text/javascript" src="<?=base_url()?>assets/admin/js/vroom.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin/js/TweenLite.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/admin/js/CSSPlugin.min.js"></script>
<script src="<?=base_url()?>assets/admin/js/jquery.nicescroll.js"></script>
<script src="<?=base_url()?>assets/admin/js/scripts.js"></script>

<!-- Bootstrap Core JavaScript -->
   <script src="<?=base_url()?>assets/admin/js/bootstrap.min.js"></script>
</body>
</html>