 									 <!--footer section start-->
										<footer>
										   <p>&copy 2017 Eşsiz Blog . Tüm Hakları Saklıdır | <a href="https://facebook.com/essizbiradam" target="_blank">Hasan Akgül</a> Tarafından Tasarlandı.</p>
										</footer>
									<!--footer section end-->